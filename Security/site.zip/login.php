<?php

	echo '<FORM action = "verify.php" method = POST >
			USERNAME: <input type = "text" id = "USER" name= "USER" /><br>
			PASSWORD: <input type = "password" id = "pw" name = "PW"><br>
			<input type = "Submit" value = "LOG IN"></FORM>';
	echo '<FORM action = \'signup.php\' ><input type = \'SUBMIT\' value = \'SIGN UP\'></FORM>'
?>